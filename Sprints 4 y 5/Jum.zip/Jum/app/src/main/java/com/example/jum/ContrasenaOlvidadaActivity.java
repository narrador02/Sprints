package com.example.jum;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ContrasenaOlvidadaActivity extends AppCompatActivity {
    EditText etCorreoRecuperacion;
    Button btnEnviarRecuperacion;
    TextView tvVolverLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contrasena_olvidada);

        // Referencias a los elementos
        etCorreoRecuperacion = findViewById(R.id.etCorreoRecuperacion);
        btnEnviarRecuperacion = findViewById(R.id.btnEnviarRecuperacion);
        tvVolverLogin = findViewById(R.id.tvVolverLogin);

        // Botón Enviar
        btnEnviarRecuperacion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String correo = etCorreoRecuperacion.getText().toString();

                if (correo.isEmpty()) {
                    Toast.makeText(ContrasenaOlvidadaActivity.this, "Introduce tu correo", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(ContrasenaOlvidadaActivity.this, "Correo de recuperación enviado", Toast.LENGTH_SHORT).show();
                    // Lógica para enviar el correo de recuperación
                }
            }
        });

        // Texto: Volver a inicio de sesión
        tvVolverLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Cierra la actividad actual y regresa a la anterior
            }
        });
    }
}
