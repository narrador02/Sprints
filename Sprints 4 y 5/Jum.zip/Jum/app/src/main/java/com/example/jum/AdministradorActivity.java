package com.example.jum;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class AdministradorActivity extends AppCompatActivity {
    Button btnGestionar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_administrador);
        btnGestionar = findViewById(R.id.btnGestionar);

        // Configurar el botón para abrir GestionarUsuarioActivity
        btnGestionar.setOnClickListener(view -> {
            Intent intent = new Intent(AdministradorActivity.this, GestionarUsuarioActivity.class);
            startActivity(intent);
        });
        Button btnAgregarUsuario = findViewById(R.id.btnAgregarUsuario);
        btnAgregarUsuario.setOnClickListener(v -> {
            Intent intent = new Intent(AdministradorActivity.this, AgregarUsuarioActivity.class);
            startActivity(intent);
        });
        Button btnSalir = findViewById(R.id.btnSalir);
        btnSalir.setOnClickListener(v -> {
            // Volver al MainActivity y limpiar la pila de actividades
            Intent intent = new Intent(AdministradorActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });


    }
}
