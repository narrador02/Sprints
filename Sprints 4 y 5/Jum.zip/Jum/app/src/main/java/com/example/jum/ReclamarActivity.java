package com.example.jum;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ReclamarActivity extends AppCompatActivity {

    RadioGroup rgEstado;
    RadioButton rbPresente, rbAusente, rbRetraso, rbJustificada;
    EditText etExplicacion;
    Button btnEnviarReclamo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reclamar);

        // Referencias a los elementos
        rgEstado = findViewById(R.id.rgEstado);
        rbPresente = findViewById(R.id.rbPresente);
        rbAusente = findViewById(R.id.rbAusente);
        rbRetraso = findViewById(R.id.rbRetraso);
        rbJustificada = findViewById(R.id.rbJustificada);
        etExplicacion = findViewById(R.id.etExplicacion);
        btnEnviarReclamo = findViewById(R.id.btnEnviarReclamo);

        // Lógica del botón Enviar Reclamo
        btnEnviarReclamo.setOnClickListener(v -> {
            String estadoSeleccionado = "";

            if (rbPresente.isChecked()) {
                estadoSeleccionado = "Presente";
            } else if (rbAusente.isChecked()) {
                estadoSeleccionado = "Ausente";
            } else if (rbRetraso.isChecked()) {
                estadoSeleccionado = "Retraso";
            } else if (rbJustificada.isChecked()) {
                estadoSeleccionado = "Ausencia Justificada";
            }

            String explicacion = etExplicacion.getText().toString().trim();

            if (estadoSeleccionado.isEmpty()) {
                Toast.makeText(this, "Seleccione el estado correcto", Toast.LENGTH_SHORT).show();
            } else if (explicacion.isEmpty()) {
                Toast.makeText(this, "Explique el motivo de la reclamación", Toast.LENGTH_SHORT).show();
            } else {
                // Aquí se simula el envío de la reclamación
                Toast.makeText(this, "Petición enviada al profesor correctamente", Toast.LENGTH_LONG).show();
                finish(); // Cierra la actividad después del envío
            }
        });
    }
}
