package com.example.jum;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AlumnoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alumno);

        Button btnReclamar = findViewById(R.id.btnReclamar);

        btnReclamar.setOnClickListener(v -> {
            Toast.makeText(this, "Redirigiendo a reclamación de asistencia", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(AlumnoActivity.this, ReclamarActivity.class);
            startActivity(intent);
        });
        Button btnSalir = findViewById(R.id.btnSalir);
        btnSalir.setOnClickListener(v -> {
            // Volver al MainActivity y limpiar la pila de actividades
            Intent intent = new Intent(AlumnoActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });


    }
}
