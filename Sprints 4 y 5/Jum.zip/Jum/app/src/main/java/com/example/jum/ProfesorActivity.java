package com.example.jum;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class ProfesorActivity extends AppCompatActivity {

    Button btnVerModificar, btnHorario, btnPasarLista, btnInformacion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profesor);

        // Referencias a los botones
        btnVerModificar = findViewById(R.id.btnVerModificar);
        btnHorario = findViewById(R.id.btnHorario);
        btnPasarLista = findViewById(R.id.btnPasarLista);
        btnInformacion = findViewById(R.id.btnInformacion);

        // Acción para botón Ver/Modificar
        btnVerModificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfesorActivity.this, VerModificarActivity.class);
                startActivity(intent);
            }
        });

        // Acción para botón Horarios
        btnHorario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfesorActivity.this, HorarioActivity.class);
                startActivity(intent);
            }
        });

        // Acción para botón Pasar Lista
        btnPasarLista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfesorActivity.this, PasarListaActivity.class);
                startActivity(intent);
            }
        });

        // Acción para botón Información
        btnInformacion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfesorActivity.this, InformacionProfesorActivity.class);
                startActivity(intent);
            }
        });
        Button btnSalir = findViewById(R.id.btnSalir);
        btnSalir.setOnClickListener(v -> {
            // Volver al MainActivity y limpiar la pila de actividades
            Intent intent = new Intent(ProfesorActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });

    }
}
