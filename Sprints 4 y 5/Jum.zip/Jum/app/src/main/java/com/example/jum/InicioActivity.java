package com.example.jum;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class InicioActivity extends AppCompatActivity {
    EditText etEmail, etPassword;
    Button btnLogin;
    TextView tvRegister, tvForgotPassword;
    String rolSeleccionado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        // Referencias
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvRegister = findViewById(R.id.tvNoAccount);
        tvForgotPassword = findViewById(R.id.tvForgotPassword);

        // Obtener rol seleccionado desde MainActivity
        rolSeleccionado = getIntent().getStringExtra("ROL");

        // Botón de iniciar sesión
        btnLogin.setOnClickListener(view -> {
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Por favor, rellena todos los campos", Toast.LENGTH_SHORT).show();
            } else {
                // Redirigir a la actividad correspondiente según el rol
                Intent intent;
                switch (rolSeleccionado) {
                    case "ALUMNO":
                        intent = new Intent(InicioActivity.this, AlumnoActivity.class);
                        break;
                    case "PROFESOR":
                        intent = new Intent(InicioActivity.this, ProfesorActivity.class);
                        break;
                    case "ADMINISTRADOR":
                        intent = new Intent(InicioActivity.this, AdministradorActivity.class);
                        break;
                    default:
                        Toast.makeText(this, "Error: Rol no definido", Toast.LENGTH_SHORT).show();
                        return;
                }
                startActivity(intent);
            }
        });

        // Redirige a la pantalla de registro
        tvRegister.setOnClickListener(view -> {
            Intent intent = new Intent(InicioActivity.this, RegistroActivity.class);
            startActivity(intent);
        });

        // Redirige a la pantalla de recuperación de contraseña
        tvForgotPassword.setOnClickListener(view -> {
            Intent intent = new Intent(InicioActivity.this, ContrasenaOlvidadaActivity.class);
            startActivity(intent);
        });
    }
}
