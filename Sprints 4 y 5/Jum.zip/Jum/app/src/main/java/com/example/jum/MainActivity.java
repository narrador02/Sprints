package com.example.jum;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btnAreaAlumnado, btnAreaProfesorado, btnAreaAdministrador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Referencia a los botones
        btnAreaAlumnado = findViewById(R.id.btnAreaAlumnado);
        btnAreaProfesorado = findViewById(R.id.btnAreaProfesorado);
        btnAreaAdministrador = findViewById(R.id.btnAreaAdministrador);

        // Navegación a InicioActivity con el rol Alumnado
        btnAreaAlumnado.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, InicioActivity.class);
            intent.putExtra("ROL", "ALUMNO");
            startActivity(intent);
        });

        // Navegación a InicioActivity con el rol Profesorado
        btnAreaProfesorado.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, InicioActivity.class);
            intent.putExtra("ROL", "PROFESOR");
            startActivity(intent);
        });

        // Navegación a InicioActivity con el rol Administrador
        btnAreaAdministrador.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, InicioActivity.class);
            intent.putExtra("ROL", "ADMINISTRADOR");
            startActivity(intent);
        });
    }
}
