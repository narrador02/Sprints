package com.example.jum;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class HorarioActivity extends AppCompatActivity {

    EditText etHora, etModulo;
    Button btnAgregar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_horario);

        // Referencias a los elementos de la vista
        etHora = findViewById(R.id.etHora);
        etModulo = findViewById(R.id.etModulo);
        btnAgregar = findViewById(R.id.btnAgregar);

        // Acción del botón
        btnAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String hora = etHora.getText().toString();
                String modulo = etModulo.getText().toString();

                if (hora.isEmpty() || modulo.isEmpty()) {
                    Toast.makeText(HorarioActivity.this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(HorarioActivity.this, "Horario añadido: " + hora + " - " + modulo, Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
