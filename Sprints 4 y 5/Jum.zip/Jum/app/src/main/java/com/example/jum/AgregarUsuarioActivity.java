package com.example.jum;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AgregarUsuarioActivity extends AppCompatActivity {
    EditText etNombre, etApellidos, etCorreo, etDNI, etTelefono, etDireccion;
    Button btnGuardarUsuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_usuario);

        // Referencias a los campos
        etNombre = findViewById(R.id.etNombre);
        etApellidos = findViewById(R.id.etApellidos);
        etCorreo = findViewById(R.id.etCorreo);
        etDNI = findViewById(R.id.etDNI);
        etTelefono = findViewById(R.id.etTelefono);
        etDireccion = findViewById(R.id.etDireccion);
        btnGuardarUsuario = findViewById(R.id.btnGuardarUsuario);

        // Evento del botón Guardar
        btnGuardarUsuario.setOnClickListener(view -> {
            String nombre = etNombre.getText().toString();
            String apellidos = etApellidos.getText().toString();
            String correo = etCorreo.getText().toString();
            String dni = etDNI.getText().toString();
            String telefono = etTelefono.getText().toString();
            String direccion = etDireccion.getText().toString();

            if (nombre.isEmpty() || apellidos.isEmpty() || correo.isEmpty()) {
                Toast.makeText(this, "Por favor, completa los campos obligatorios.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Usuario guardado:\n" +
                        "Nombre: " + nombre + " " + apellidos + "\nCorreo: " + correo, Toast.LENGTH_LONG).show();
            }
        });
    }
}
