package com.example.jum;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class PasarListaActivity extends AppCompatActivity {

    Button btnPresente, btnAusente, btnRetraso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pasar_lista);

        // Referencias a los botones
        btnPresente = findViewById(R.id.btnPresente);
        btnAusente = findViewById(R.id.btnAusente);
        btnRetraso = findViewById(R.id.btnRetraso);

        // Lógica para botón "Presente"
        btnPresente.setOnClickListener(view ->
                Toast.makeText(PasarListaActivity.this, "Asistencia registrada: Presente", Toast.LENGTH_SHORT).show()
        );

        // Lógica para botón "Ausente"
        btnAusente.setOnClickListener(view ->
                Toast.makeText(PasarListaActivity.this, "Asistencia registrada: Ausente", Toast.LENGTH_SHORT).show()
        );

        // Lógica para botón "Retraso"
        btnRetraso.setOnClickListener(view ->
                Toast.makeText(PasarListaActivity.this, "Asistencia registrada: Retraso", Toast.LENGTH_SHORT).show()
        );
    }
}
