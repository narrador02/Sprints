package com.example.jum;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class GestionarUsuarioActivity extends AppCompatActivity {

    EditText etNombre, etApellidos, etCorreo, etDNI, etTelefono, etDireccion;
    Button btnModificar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gestionar_usuario);

        // Referencias a los EditTexts
        etNombre = findViewById(R.id.etNombre);
        etApellidos = findViewById(R.id.etApellidos);
        etCorreo = findViewById(R.id.etCorreo);
        etDNI = findViewById(R.id.etDNI);
        etTelefono = findViewById(R.id.etTelefono);
        etDireccion = findViewById(R.id.etDireccion);

        // Referencia al botón
        btnModificar = findViewById(R.id.btnModificar);

        // Acción del botón (solo visual, no funcional)
        btnModificar.setOnClickListener(view -> {
            // Mensaje ficticio
            Toast.makeText(this, "Datos modificados correctamente", Toast.LENGTH_SHORT).show();
        });
    }
}
